public class soda_jmv {
	public static void main(String[] args) {
		java.util.Scanner in = new java.util.Scanner(System.in);
		System.out.println(Math.max(0, (in.nextInt() + in.nextInt() - 1) / (in.nextInt() - 1)));
	}
}
