import java.io.*;
import java.util.*;
/* Solution by B�rge Mikkelsen 12.06.2005 */

public class Robots {

	int N = 0, E = 1, S = 2, W = 3;

	int dir(char d) {
		if (d == 'N') return N;
		if (d == 'S') return S;
		if (d == 'E') return E;
		if (d == 'W') return W;
		return -1;
	}

	void go() {
		int a = INT(), b = INT();
		int n = INT(), m = INT();
		int[][] pos = new int[n][3]; //(x, y, d)

		// read robot positions
		for (int i = 0; i < n; ++i) {
			pos[i][0] = INT();
			pos[i][1] = INT();
			pos[i][2] = dir(STR().charAt(0));
		}

		boolean ok = true, crash = false;
		int cur, min, max, hitat, hitid;

		// read and execute instructions
		for (int i = 0; i < m; ++i) {
			int id = INT() - 1; //robots are 1-indexed
			char move = STR().charAt(0);
			int repeat = INT();
			if (!ok) continue; //already crashed, skip to next test case
			if (move == 'L') {
				pos[id][2] += 3*repeat;
				pos[id][2] %= 4;
			} else if (move == 'R') {
				pos[id][2] += 1*repeat;
				pos[id][2] %= 4;
			} else if (move == 'F') {
				hitat = 100000;
				hitid = -1;
				if (pos[id][2] == N) {
					cur = pos[id][0];
					min = pos[id][1];
					max = pos[id][1] + repeat;
					for (int j = 0; j < n; ++j) {
						if (j == id) continue;
						if (pos[j][0] == cur && pos[j][1] >= min && pos[j][1] <= max) {
							if (pos[j][1] - min < hitat) {
								hitid = j;
								hitat = pos[j][1] - min;
							}
						}
					}
					if (max > b) crash = true;
					pos[id][1] = max;
				}

				if (pos[id][2] == S) {
					cur = pos[id][0];
					max = pos[id][1];
					min = pos[id][1] - repeat;
					for (int j = 0; j < n; ++j) {
						if (j == id) continue;
						if (pos[j][0] == cur && pos[j][1] >= min && pos[j][1] <= max) {
							if (max - pos[j][1] < hitat) {
								hitid = j;
								hitat = max - pos[j][1];
							}
						}
					}
					if (min < 1) crash = true;
					pos[id][1] = min;
				}

				if (pos[id][2] == E) {
					cur = pos[id][1];
					min = pos[id][0];
					max = pos[id][0] + repeat;
					for (int j = 0; j < n; ++j) {
						if (j == id) continue;
						if (pos[j][1] == cur && pos[j][0] >= min && pos[j][0] <= max) {
							if (pos[j][0] - min < hitat) {
								hitid = j;
								hitat = pos[j][0] - min;
							}
						}
					}
					if (max > a) crash = true;
					pos[id][0] = max;
				}

				if (pos[id][2] == W) {
					cur = pos[id][1];
					max = pos[id][0];
					min = pos[id][0] - repeat;
					for (int j = 0; j < n; ++j) {
						if (j == id) continue;
						if (pos[j][1] == cur && pos[j][0] >= min && pos[j][0] <= max) {
							if (max - pos[j][0] < hitat) {
								hitid = j;
								hitat = max - pos[j][0];
							}
						}
					}
					if (min < 1) crash = true;
					pos[id][0] = min;
				}
				if (hitat < 100000) {
					ok = false;
					ut.println("Robot " + (id+1) + " crashes into robot " + (hitid+1));
				} else if (crash) {
					ok = false;
					ut.println("Robot " + (id+1) + " crashes into the wall");
				}
			}
		}
		if (ok) ut.println("OK");
	}

	static int P,Q;
	public static void main(String[] s) {
 		for(Q = INT(); P++ < Q;)
			(new Robots()).go();
	}
	static PrintStream ut = System.out;
	static BufferedReader inn = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	static String LINE() {
		String s = null;
		try {s = inn.readLine();}
		catch (Exception e) {}
		return s == null ? "" : s;
	}

	static String STR() {
		while (st == null || !st.hasMoreTokens()) st = new StringTokenizer(LINE());
		return st.nextToken();
	}
	static int INT() {return Integer.parseInt(STR());}
}
