#include <iostream>

using namespace std;

int posX[101];
int posY[101];
char dir[101];

void run()
{
    int A, B;
    cin >> A >> B;
    int N, M;
    cin >> N >> M;
    for (int r = 1; r <= N; r++) {
        cin >> posX[r] >> posY[r] >> dir[r];
    }
    for (int m = 0; m < M; m++) {
        int robot;
        char action;
        int repeat;
        cin >> robot >> action >> repeat;
        if (action == 'L' || action == 'R') {
            repeat %= 4;
        }
        for (int rep = 0; rep < repeat; rep++) {
            if (action == 'F') {
                int xd = 0;
                int yd = 0;
                switch (dir[robot]) { 
                    case 'N':
                        yd = 1; break;
                    case 'E':
                        xd = 1; break;
                    case 'S':
                        yd = -1; break;
                    case 'W':
                        xd = -1; break;
                }
                posX[robot] += xd;
                posY[robot] += yd;
                if (    posX[robot] <= 0 ||
                        posX[robot] > A ||
                        posY[robot] <= 0 ||
                        posY[robot] > B) {
                    cout << "Robot " << robot << " crashes into the wall\n";
                    for (m++; m < M; m++) {
                        cin >> robot >> action >> repeat;
                    }
                    return;
                }
                for (int r = 1; r <= N; r++) {
                    if (r != robot && posX[r] == posX[robot] &&
                                      posY[r] == posY[robot]) {
                        cout << "Robot " << robot << " crashes into robot "
                             << r << "\n";
                        for (m++; m < M; m++) {
                            cin >> robot >> action >> repeat;
                        }
                        return;
                    }
                }
            }
            else if (action == 'R') {
                switch (dir[robot]) {
                    case 'N':
                        dir[robot] = 'E'; break;
                    case 'E':
                        dir[robot] = 'S'; break;
                    case 'S':
                        dir[robot] = 'W'; break;
                    case 'W':
                        dir[robot] = 'N'; break;
                }
            }
            else if (action == 'L') {
                switch (dir[robot]) {
                    case 'N':
                        dir[robot] = 'W'; break;
                    case 'W':
                        dir[robot] = 'S'; break;
                    case 'S':
                        dir[robot] = 'E'; break;
                    case 'E':
                        dir[robot] = 'N'; break;
                }
            }
        }
    }
    cout << "OK\n";
}

int main()
{
    int K;
    cin >> K;
    for (int k = 0; k < K; k++) {
        run();
    }
}
