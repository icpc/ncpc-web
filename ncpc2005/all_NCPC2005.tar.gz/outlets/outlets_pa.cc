#include <cstdio>

int main(void) {
  int n;
  scanf("%d", &n);
  for (int i = 0; i < n; ++i) {
    int r = 1, k, x;
    scanf("%d", &k);
    for (int j = 0; j < k; ++j)
      scanf("%d", &x), r += x-1;
    printf("%d\n", r);
  }
  return 0;
}
