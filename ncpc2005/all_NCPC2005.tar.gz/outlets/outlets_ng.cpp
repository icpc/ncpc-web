#include <iostream>

using namespace std;

int main()
{
    int N;
    cin >> N;
    for (int i = 0; i < N; i++) {
        int K;
        cin >> K;
        int free = 1;
        for (int j = 0; j < K; j++) {
            int O;
            cin >> O;
            free += O - 1;
        }
        cout << free << endl;
    }
}
