/*
	Contains both the fast reference solution (prepare()+eval()),
	and a slow recursive solution (solve()) for validation.
*/


import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.lang.reflect.Array;

public class Spill {
	
	int n;
	double[] alt;
	double start;
	HashMap hm;
	double eps = 1e-9;
	
	boolean oldval;
	TreeMap tm = new TreeMap();
	boolean eval(double val) {
		Object key = new Double(val+eps);
		SortedMap sm = tm.tailMap(key);
		boolean svar = sm.isEmpty()?oldval:((Boolean)sm.get(sm.firstKey())).booleanValue();
		//ut.println(val+" eval " +svar+(sm.isEmpty()?" empty":""));
		return svar;
	}
	
	void add(double lim, boolean val) {
//		ut.println("added "+lim+" " +val);
		tm.put(new Double(lim),Boolean.valueOf(val));
	}
	
	TreeSet pot = new TreeSet();
	void prepare(double max) {
		long tid = System.currentTimeMillis();
		for (int i=0; i<n; ++i) pot.add(new Double(1/alt[i]));
		tm.put(new Double(1),Boolean.valueOf(false));
		double oldlim = 1;
		oldval = true;
		while (true) {
			Double key = (Double)pot.first();
			double lim = key.doubleValue();
			if (oldlim>max) break;
			pot.remove(key);
			if (lim-oldlim<eps) continue;
			boolean ans = false;
			for (int i=0; !ans && i<n; ++i) {
				ans = !eval(lim*alt[i]);
			}
			if (ans!=oldval) {
//				ut.println((lim-oldlim)+" "+oldval+" "+lim);
				add(lim,oldval);
				for (int i=0; i<n; ++i) pot.add(new Double(lim/alt[i]));
			}
			oldlim = lim;
			oldval = ans;
		}
		//System.err.println(System.currentTimeMillis()-tid);
	}
	
	boolean solve(int[] koeff, double val) {
		if (val<=1) return false;
		int[] copy = new int[n];
		System.arraycopy(koeff,0,copy,0,n);
		Index key = new Index(copy);
		Boolean bool = (Boolean)hm.get(key);
		if (bool==null) {
			boolean ans = false;
			for (int i=0; !ans && i<n; ++i) {
				++copy[i];
				ans = !solve(copy,val*alt[i]);
				--copy[i];
			}
			bool = Boolean.valueOf(ans);
			hm.put(key,bool);
		}
		return bool.booleanValue();
	}

	void go() {
		double X = DBL();
		n = Index.ant = INT();
		alt = new double[n];
		for (int i=0; i<n; ++i) alt[i] = DBL();
		//		ut.println("X="+X);
		dump("alt",alt);
		prepare(X);
		hm = new HashMap();
		//		boolean svar1 = solve(new int[n],X);
		boolean svar2 = eval(X);
		//		ut.println(svar1+" "+svar2);
		System.out.println(svar2?"Nils":"Mikael");
		//		ut.println(tm);
	}

	public static void main(String[] s) {
		int N = INT();
		for (int i=0; i<N; ++i)
			new Spill().go();
	}
	static DataInputStream ds = new DataInputStream(System.in);
	static PrintStream ut = System.err;
	static StringTokenizer st;
	static String STR() {
		while (st==null || !st.hasMoreTokens()) st=new StringTokenizer(read());
		return st.nextToken();
	}
	static int INT() {return Integer.parseInt(STR());}
	static double DBL() {return Double.parseDouble(STR());}
	
	static String read() { try { 
		return ds.readLine();
	}catch(Exception e) { throw new Error(e); } }
	
	static void dump(String s,Object o) {
		int n = Array.getLength(o);
		/*
		for(int i=0;i<n;i++) {
			Object e = Array.get(o,i);
			if(e!=null && e.getClass().isArray()) dump(s+" "+i, e);
			else ut.print((i==0?s+" = ":",")+e);
		}
		ut.println();
		*/
	}

}

class Index implements Comparable {
	static int ant = 4; // m� settes til det antallet indekser som skal brukes
	static int sha = 32/(ant+1);
	int[] ind;
	public Index(int[] ind) {
		this.ind = ind;
	}
	public boolean equals(Object o) {
		Index oo = (Index)o;
		for (int i=0; i<ant; ++i) {
			if (ind[i]!=oo.ind[i]) return false;
		}
		return true;
	}
	public int hashCode() {
		int akk=1;
		for (int i=0; i<ant; ++i) akk ^= (ind[i]<<(sha*(i+1))) ^ ind[i];
		return akk;
	}
	public boolean negative() {
		for (int i=0; i<ant; ++i) {
			if (ind[i]<0) return true;
		}
		return false;
	}
	public int compareTo(Object o) {
		Index oo = (Index)o;
		for (int i=0; i<ant; ++i) {
			if (ind[i]<oo.ind[i]) return -1;
			if (ind[i]>oo.ind[i]) return  1;
		}
		return 0;
	}
	public static Index get(int a, int b) {return new Index(new int[]{a,b});}
}

/*
		for (Iterator it=tm.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry me = (Map.Entry)it.next();
			ut.println(me);
		}
	boolean eval(double val) {
		Object key = new Double(val);
		SortedMap sm = tm.tailMap(key);
		if (sm.isEmpty()) {
			boolean ans = false;
			for (int i=0; !ans && i<n; ++i) {
				ans = !eval(val*alt[i]);
			}
			Object lastkey = tm.lastKey();
			boolean lastval = ((Boolean)tm.get(lastkey)).booleanValue();
			if (lastval==ans) {
				tm.remove(lastkey);
			}
			tm.put(key,Boolean.valueOf(ans));
			return ans;
		} else {
			key = sm.firstKey();
			return ((Boolean)sm.get(key)).booleanValue();
		}
	}
*/
