import java.util.*;
import java.io.*;


class Node implements Comparable
{
    int ylo, yhi; // interval of years
    int mx;       // max known rainfall in interval
    int ny;       // number of known years in interval
    Node left, right;  
    
    
    void print(int n) 
    {

	return;
	/*
	for (int i = 0; i < n; ++i) 
	    System.out.print(' ');
	System.out.println(ylo + ' ' + yhi + ' ' + mx + ' ' +ny);
	if (left != null) {
	    left.print(n+2);
	    right.print(n+2);
	}
	
	for (int i = 0; i < n; ++i) System.out.print(' ');
	System.out.println(')');
	*/	
    }
    
    Node(int y1, int y2, int m, int n, Node lft, Node rte) 
    { 
	ylo=y1; yhi=y2; mx=m;
	ny=n; left=lft; right=rte;  
    } 
    
    Node(int y, int fall) 
    {
	this(y, y, fall, 1, null, null);
    }
    
    Node(Node u, Node v) 
    {
	this(u.ylo, v.yhi, Math.max(u.mx, v.mx), u.ny+v.ny, u, v);
    }
    
    /* return max known rain in interval years [y1,y2]
     * return -1 if no rainfall is known in interval
     * return 0 if y1 > y2
     * (1) and (2) cover leaf case.
     */
    int fall(int y1, int y2) 
    {
	if (y1 > y2) return 0;    
	if (y1 > yhi || y2 <ylo) return -1; // (1)
	if (y1 <= ylo && y2 >= yhi) return mx; // (2)
	return Math.max(left.fall(y1, y2), right.fall(y1, y2));
    }
    
    int fall(int y)   {  return fall(y,y);   }
    
    /* return number of known years in interval [y1,y2]
     * (1) and (2) cover leaf case.
     */
    int num(int y1, int y2) 
    {
	if (y1 > yhi || y2 <ylo) return 0; // (1)
	if (y1 <= ylo && y2 >= yhi) return ny; // (2)
	return left.num(y1, y2) + right.num(y1, y2);
    }
    
    public int compareTo(Object o) 
    {
	Node n = (Node) o;
	return ylo - n.ylo;	
    }
}

class weather_mg 
{
    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter out = new PrintWriter(new BufferedOutputStream(System.out));
    public static void main(String[] ss) 	 throws Exception
    {
	for (int cnt=0;	
	     new weather_mg().solve(cnt);
	     ++cnt)
	    ;
	out.flush();
    }
    
	
    boolean solve(int nc) throws Exception
    {
	if (nc>0) in.readLine();

	String pars[];
	int n = Integer.parseInt(in.readLine());
	if(n==0) return false;
	Node[] nodes = new Node[n];
	int i,j;
	
	if (nc>0) out.println();

	for(i=0; i < n; ++i) {
	    StringTokenizer st = new StringTokenizer(in.readLine());
	    int y = Integer.parseInt(st.nextToken());
	    int r = Integer.parseInt(st.nextToken());
	    nodes[i] = new Node(y,r);    
	}

	//	Arrays.sort(nodes);
  
	while (n>1) {
	    i=j=0;
	    while (j<n) 
		if (j==n-1) 
		    nodes[i++] = nodes[j++];
		else {
		    nodes[i++] = new Node(nodes[j], nodes[j+1]);
		    j += 2;
		}
	    n -= n/2;
	}
	
	Node stat = nodes[0];

	
	int m = Integer.parseInt(in.readLine()),y1,y2;
	for (i=0; i < m; ++i) {
	    String s = "CANNOT HAPPEN";    
	    StringTokenizer st = new StringTokenizer(in.readLine());
	    y1 = Integer.parseInt(st.nextToken());
	    y2 = Integer.parseInt(st.nextToken());
	    if (y1 >= y2) 
		s = "y1 >= y2 MAKES NO SENSE";
	    else { // y1 < y2
		int f1 = stat.fall(y1);
		int f2 = stat.fall(y2);
		int max_between = stat.fall(y1+1, y2-1);      
		int num_between = stat.num(y1+1, y2-1);
		
		
		if (f1 < 0 && f2 < 0) 
		    s = "maybe";
		else { // >= one of y1, y2 is known	
		    if (y1 == y2-1) { // no years between
			if (f2 == 0)  
			    s = "true";
			else if (f1 < 0 || f2 < 0)  
			    s = "maybe";
			else  
			    s = (f1 >= f2) ? "true" : "false";
		    }
		    else if (f2 < 0) 
			s = (max_between < f1) ? "maybe" : "false";  
		    else if (f2 == 0) 
			s = "false";
		    else if (max_between >= f2)
			s = "false";
		    else if (f1 < 0) 
			s = "maybe";
		    else if (f1 < f2) 
			s = "false";
		    else // f1 and f2 known, f1 >= f2 and max_between < f2
			s = (num_between == y2-y1-1) ? "true" : "maybe";
		}
	    }
	    out.println(s);
	    
	}
	
	return true;
	
    }
}
