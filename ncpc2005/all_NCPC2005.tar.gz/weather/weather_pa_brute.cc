/* Brute force solution to "Worst Weather Ever" problem.
 *
 * This solution is supposed to get TLE on the judge data.
 * 
 * Author: Per Austrin
 */

#include <cstdio>
#include <algorithm>

using namespace std;
typedef pair<int, int> pii;

int totsteps = 0;

int max_between(pii *x, pii *y, int lim) {
  int r = 0;
  for ( ; ++x != y && r <= lim; )
    r >?= x->second, ++totsteps;
  return r;
}

bool solve(int P) {
  pii known[55000];
  int n, m;
  if (scanf("%d", &n) != 1 || !n) return false;

  ++n;
  for (int i = 1; i < n; ++i)
    scanf("%d%d", &known[i].first, &known[i].second);
  known[0] = pii(-(1<<30), 1<<30);
  known[n] = pii(1<<30,  1<<30);
  ++n;
  
  scanf("%d", &m);
  if (P) printf("\n");
  for (int i = 0; i < m; ++i) {
    int x, y;
    scanf("%d%d", &y, &x);
    pii *X = upper_bound(known, known+n, pii(x, -1));
    pii *Y = upper_bound(known, known+n, pii(y, -1));
    if (X->first == x && Y->first == y) {
      if (Y->second < X->second) printf("false\n");
      else {
	int m = max_between(Y, X, X->second);
	if (X->second <= m) printf("false\n");
	else if (X - Y == x - y) printf("true\n");
	else printf("maybe\n");
      }
    } else if (X->first == x) {
      int m = max_between(Y-1, X, X->second);
      if (m < X->second) printf("maybe\n");
      else printf("false\n");
    } else if (Y->first == y) {
      int m = max_between(Y, X, Y->second);
      if (m < Y->second) printf("maybe\n");
      else printf("false\n");
    } else {
      printf("maybe\n");
    }
  }
  return true;
}

int main() {
  for (int i = 0; solve(i); ++i);
  fprintf(stderr, "totsteps %d\n", totsteps);
  return 0;
}
