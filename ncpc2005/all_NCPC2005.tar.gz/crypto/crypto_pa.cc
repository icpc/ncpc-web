/* Sample solution to "The Embarrased Cryptographer" from NCPC 2005
 * Algorithm: compute M % p for all primes p < L
 * Author: Per Austrin
 */ 
#include <cstdio>
#include <cstring>
const long long B = 1000000000;
int res(int *v, int s, int m) { return s+1 ? (*v+B*res(v+1,s-1,m)) % m : 0; }
main(void) {
  int L, K[200], pr[100000], i, b, l, p, ps = 0;
  char ip[529042], k[200], *a[] = {"GOOD\n", "BAD %d\n"};
  for(memset(ip, 42, 529042), p = 2; 999*p < B; p += 1+(p>2))
    if(ip[p>>1] && (pr[ps++]=p) && p < 1023 && p > 2)
      for(int pp = p*p; ip[pp>>1] = 0, 999*pp < B; pp += p<<1);
  for(p=1; scanf("%s%n%d",k,&l,&L), l-=p, L; printf(a[pr[i]<L], pr[i]), p=2) {
    for(memset(K,0,400),i=-1,b=1;k[++i];(b*=10)%=(B-1)) K[i/9]+=b*(k[l-i]-48);
    for(i = 0; i < ps && pr[i] < L && res(K, l/9, pr[i]); ++i) ;
  }
}
