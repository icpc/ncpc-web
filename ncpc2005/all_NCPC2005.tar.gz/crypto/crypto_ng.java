import java.io.*;
import java.math.*;
import java.util.*;

public class crypto_ng {

    static final BigInteger ZERO = BigInteger.valueOf(0);
    static final BigInteger ONE = BigInteger.valueOf(1);
    static final BigInteger TWO = BigInteger.valueOf(2);
    static final BigInteger THREE = BigInteger.valueOf(3);
    static final BigInteger TEN = BigInteger.valueOf(10);

    static ArrayList<BigInteger> primes = new ArrayList<BigInteger>();

    static void generate_slow(BigInteger max) {
        primes.add(TWO);
        for (BigInteger j = THREE; j.compareTo(max) < 0; j = j.add(TWO)) {
            boolean isprime = true;
            BigInteger lim = new BigDecimal(
                    Math.sqrt(j.doubleValue())).toBigInteger();
            for (int k = 0; k < primes.size() && 
                    primes.get(k).compareTo(lim) <= 0; k++) {
                if (j.mod(primes.get(k)).equals(ZERO)) {
                    isprime = false;
                    break;
                }
            }
            if (isprime) {
                primes.add(j);
            }
        }
    }
    
    static void generate(int max) {
        int n = Math.max(100, max / 10);
        int[] iprimes = new int[n];
        iprimes[0] = 2;
        int num_primes = 1;
        for (int j = 3; j < max; j += 2) {
            boolean isprime = true;
            int lim = (int)Math.sqrt(j);
            for (int k = 0; k < num_primes && iprimes[k] <= lim; k++) {
                if (j % iprimes[k] == 0) {
                    isprime = false;
                    break;
                }
            }
            if (isprime) {
                if (num_primes >= n) {
                    System.err.println("Realloc");
                    n <<= 1;
                    int[] niprimes = new int[n];
                    for (int k = 0; k < num_primes; k++) {
                        niprimes[k] = iprimes[k];
                    }
                    iprimes = niprimes;
                }
                iprimes[num_primes++] = j;
            }
        }
        for (int k = 0; k < num_primes; k++) {
            primes.add(BigInteger.valueOf(iprimes[k]));
        }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        generate((int)1E6);
        //generate_slow(TEN.pow(6));
        while (true) {
            StringTokenizer st = new StringTokenizer(bf.readLine());
            BigInteger K = new BigInteger(st.nextToken());
            BigInteger L = new BigInteger(st.nextToken());
            if (K.equals(BigInteger.ZERO)) {
                return;
            }
            boolean ok = true;
            for (int j = 0; j < primes.size() && 
                    primes.get(j).compareTo(L) < 0; j++) {
                if (K.mod(primes.get(j)).equals(BigInteger.ZERO)) {
                    System.out.println("BAD " + primes.get(j));
                    ok = false;
                    break;
                }
            }
            if (ok) {
                System.out.println("GOOD");
            }
        }
    }
}
