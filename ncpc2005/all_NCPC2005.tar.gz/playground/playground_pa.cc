/* Sample solution to "Playground" from NCPC 2005
 * Algorithm: trivial
 * Author: Per Austrin
 */ 
#include <cstdio>
#include <algorithm>

int main(void) {
  for (int k, i; scanf("%d", &k)==1 && k; printf("%s\n", i<k ? "YES" : "NO")) {
    double v[10000], sum = 0;
    for (i = 0; i < k; ++i) scanf("%lf", v+i);
    std::sort(v, v+i);
    for (i = 0; i < k; sum += v[i++]) if (sum > v[i]-1e-10) break;
  }
}
