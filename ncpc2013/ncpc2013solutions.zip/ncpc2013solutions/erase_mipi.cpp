#include <cstdio>
#include <climits>
#include <cstdlib>
#include <cassert>
#include <cmath>
#include <cctype>
#include <cerrno>
#include <algorithm>
#include <list>
#include <queue>
#include <map>
#include <vector>
#include <cstring>

using namespace std;
    
#define REP(i,n) for(int _n=(n),i=0; i<_n; ++i)
#define FOR(i,a,b) for(int _b=(b),i=(a); i<=_b; ++i)
#define FORD(i,a,b) for(int _b=(b),i=(a); i>=_b; --i)
#define FORE(i,a)  for(VAR(i,a.begin()); i!=a.end(); ++i)

#define PB push_back
#define BEG begin()
#define END end()
#define SZ size()
#define MP make_pair
#define F first
#define S second
#define D double
#define LL long long
#define LD long double
#define VI vector<int>

int main(){
	int n;
	char buf1[3000], buf2[3000];
	scanf("%d\n",&n);
	gets(buf1); gets(buf2);
	int m=strlen(buf1);
	REP(i,m)
		if ((n&1)!=(buf1[i]!=buf2[i])) goto hell;
	printf("Deletion succeeded\n");
	return 0;
hell:
	printf("Deletion failed\n");
	return 0;
}
